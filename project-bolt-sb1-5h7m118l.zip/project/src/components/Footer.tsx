import React from 'react';
import { ShoppingBag, Phone, Mail, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <ShoppingBag className="h-8 w-8 text-amber-600" />
              <span className="text-xl font-bold">优质纸袋</span>
            </div>
            <p className="text-gray-400 mb-6 leading-relaxed">
              专业的肉夹馍纸袋制造商，致力于为餐饮行业提供高质量、环保的包装解决方案。
              我们以诚信为本，品质为先，为每一位客户提供优质的产品和服务。
            </p>
            <div className="flex space-x-4">
              <button className="bg-amber-600 text-white px-6 py-2 rounded-full hover:bg-amber-700 transition-colors">
                立即咨询
              </button>
              <button className="border border-amber-600 text-amber-600 px-6 py-2 rounded-full hover:bg-amber-600 hover:text-white transition-colors">
                下载手册
              </button>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">快速链接</h3>
            <ul className="space-y-2">
              <li><a href="#home" className="text-gray-400 hover:text-white transition-colors">首页</a></li>
              <li><a href="#products" className="text-gray-400 hover:text-white transition-colors">产品展示</a></li>
              <li><a href="#features" className="text-gray-400 hover:text-white transition-colors">产品优势</a></li>
              <li><a href="#about" className="text-gray-400 hover:text-white transition-colors">关于我们</a></li>
              <li><a href="#contact" className="text-gray-400 hover:text-white transition-colors">联系我们</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">联系信息</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-2 text-gray-400">
                <Phone className="h-4 w-4" />
                <span>400-123-4567</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-400">
                <Mail className="h-4 w-4" />
                <span>info@paperbag.com</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-400">
                <MapPin className="h-4 w-4" />
                <span>北京市朝阳区XX路XX号</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2024 优质纸袋. 保留所有权利.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">隐私政策</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">服务条款</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">网站地图</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;