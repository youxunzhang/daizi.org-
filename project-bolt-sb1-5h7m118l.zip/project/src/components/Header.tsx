import React, { useState } from 'react';
import { Menu, X, ShoppingBag } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-md fixed w-full top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-2">
            <ShoppingBag className="h-8 w-8 text-amber-600" />
            <span className="text-xl font-bold text-gray-900">优质纸袋</span>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <a href="#home" className="text-gray-700 hover:text-amber-600 transition-colors">首页</a>
            <a href="#products" className="text-gray-700 hover:text-amber-600 transition-colors">产品展示</a>
            <a href="#features" className="text-gray-700 hover:text-amber-600 transition-colors">产品优势</a>
            <a href="#about" className="text-gray-700 hover:text-amber-600 transition-colors">关于我们</a>
            <a href="#contact" className="text-gray-700 hover:text-amber-600 transition-colors">联系我们</a>
          </nav>

          <button
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden pb-4">
            <nav className="flex flex-col space-y-2">
              <a href="#home" className="text-gray-700 hover:text-amber-600 py-2">首页</a>
              <a href="#products" className="text-gray-700 hover:text-amber-600 py-2">产品展示</a>
              <a href="#features" className="text-gray-700 hover:text-amber-600 py-2">产品优势</a>
              <a href="#about" className="text-gray-700 hover:text-amber-600 py-2">关于我们</a>
              <a href="#contact" className="text-gray-700 hover:text-amber-600 py-2">联系我们</a>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;