import React from 'react';
import { Factory, Users, Award, Truck } from 'lucide-react';

const About = () => {
  const stats = [
    { icon: Factory, number: '10+', label: '年专业经验' },
    { icon: Users, number: '5000+', label: '服务客户' },
    { icon: Award, number: '50+', label: '行业认证' },
    { icon: Truck, number: '99%', label: '准时交付率' }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                关于我们
              </h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  我们是一家专注于餐饮包装行业的专业公司，成立于2014年。
                  十年来，我们始终致力于为餐饮企业提供高质量、环保的包装解决方案。
                </p>
                <p>
                  从最初的小作坊到如今的现代化生产基地，我们始终坚持以客户需求为导向，
                  不断创新产品设计，提升产品质量，赢得了行业内外的广泛认可。
                </p>
                <p>
                  我们的使命是让每一份美食都拥有完美的包装，
                  让每一个品牌都能通过精美的包装传递自己的价值理念。
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat, index) => (
                <div key={index} className="text-center p-4 bg-amber-50 rounded-2xl">
                  <div className="flex items-center justify-center mb-2">
                    <stat.icon className="h-8 w-8 text-amber-600" />
                  </div>
                  <div className="text-2xl font-bold text-gray-900 mb-1">
                    {stat.number}
                  </div>
                  <div className="text-sm text-gray-600">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              <img
                src="https://images.pexels.com/photos/5466785/pexels-photo-5466785.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="生产车间"
                className="rounded-2xl shadow-lg"
              />
              <img
                src="https://images.pexels.com/photos/4686175/pexels-photo-4686175.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="产品展示"
                className="rounded-2xl shadow-lg mt-8"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 bg-amber-600 text-white p-6 rounded-2xl shadow-xl">
              <div className="text-sm font-semibold">品质保证</div>
              <div className="text-lg font-bold">ISO认证</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;