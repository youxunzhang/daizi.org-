import React from 'react';
import { Package } from 'lucide-react';

const Products = () => {
  const products = [
    {
      name: '经典款肉夹馍纸袋',
      description: '经典设计，适合各种规格的肉夹馍包装',
      image: 'https://images.pexels.com/photos/4686166/pexels-photo-4686166.jpeg?auto=compress&cs=tinysrgb&w=600',
      features: ['防油涂层', '食品级纸张', '可定制印刷']
    },
    {
      name: '加厚防漏纸袋',
      description: '双层加厚设计，完美防止汤汁渗漏',
      image: 'https://images.pexels.com/photos/4686175/pexels-photo-4686175.jpeg?auto=compress&cs=tinysrgb&w=600',
      features: ['双层加厚', '超强防漏', '手感舒适']
    },
    {
      name: '环保牛皮纸袋',
      description: '纯天然牛皮纸材质，环保健康首选',
      image: 'https://images.pexels.com/photos/4686178/pexels-photo-4686178.jpeg?auto=compress&cs=tinysrgb&w=600',
      features: ['100%环保', '可降解', '天然材质']
    },
    {
      name: '精装礼品纸袋',
      description: '精美包装设计，适合节日礼品装',
      image: 'https://images.pexels.com/photos/4686823/pexels-photo-4686823.jpeg?auto=compress&cs=tinysrgb&w=600',
      features: ['精美设计', '节日定制', '礼品装']
    }
  ];

  return (
    <section id="products" className="py-20 bg-gradient-to-br from-gray-50 to-amber-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            精选产品系列
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            多种规格、多种材质，满足不同商家的包装需求
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product, index) => (
            <div
              key={index}
              className="group bg-white rounded-3xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-4"
            >
              <div className="relative overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute top-4 right-4 bg-amber-600 text-white p-2 rounded-full">
                  <Package className="h-4 w-4" />
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-2">
                  {product.name}
                </h3>
                <p className="text-gray-600 mb-4 text-sm leading-relaxed">
                  {product.description}
                </p>
                
                <div className="space-y-2 mb-4">
                  {product.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center text-sm text-gray-600">
                      <div className="w-2 h-2 bg-amber-500 rounded-full mr-2"></div>
                      {feature}
                    </div>
                  ))}
                </div>
                
                <button className="w-full bg-amber-600 text-white py-2 px-4 rounded-full font-semibold hover:bg-amber-700 transition-colors">
                  了解详情
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Products;