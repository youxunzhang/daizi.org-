import React from 'react';
import { Star, Award, Users } from 'lucide-react';

const Hero = () => {
  return (
    <section id="home" className="pt-16 bg-gradient-to-br from-amber-50 to-orange-100 min-h-screen flex items-center">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl md:text-6xl font-bold text-gray-900 leading-tight">
                专业
                <span className="text-amber-600"> 肉夹馍</span>
                <br />
                纸袋定制
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                为您的肉夹馍提供最优质的包装解决方案，
                <br />
                环保材质，精美设计，让美食更有品味
              </p>
            </div>

            <div className="flex flex-wrap gap-4">
              <button className="bg-amber-600 text-white px-8 py-3 rounded-full font-semibold hover:bg-amber-700 transition-colors transform hover:scale-105">
                立即咨询
              </button>
              <button className="border-2 border-amber-600 text-amber-600 px-8 py-3 rounded-full font-semibold hover:bg-amber-600 hover:text-white transition-colors">
                查看产品
              </button>
            </div>

            <div className="grid grid-cols-3 gap-8 pt-8">
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Star className="h-6 w-6 text-amber-500" />
                </div>
                <div className="text-2xl font-bold text-gray-900">5000+</div>
                <div className="text-sm text-gray-600">满意客户</div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Award className="h-6 w-6 text-amber-500" />
                </div>
                <div className="text-2xl font-bold text-gray-900">10年</div>
                <div className="text-sm text-gray-600">行业经验</div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Users className="h-6 w-6 text-amber-500" />
                </div>
                <div className="text-2xl font-bold text-gray-900">100%</div>
                <div className="text-sm text-gray-600">环保材质</div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="bg-white rounded-3xl shadow-2xl p-8 transform rotate-3 hover:rotate-0 transition-transform duration-300">
              <img
                src="https://images.pexels.com/photos/4686820/pexels-photo-4686820.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="肉夹馍纸袋"
                className="w-full h-96 object-cover rounded-2xl"
              />
            </div>
            <div className="absolute -bottom-4 -left-4 bg-amber-600 text-white p-4 rounded-2xl shadow-lg">
              <div className="text-sm font-semibold">限时优惠</div>
              <div className="text-lg font-bold">85折起</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;