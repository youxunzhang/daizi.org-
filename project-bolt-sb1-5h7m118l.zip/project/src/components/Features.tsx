import React from 'react';
import { Shield, Leaf, Zap, Heart, Truck, Phone } from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: Shield,
      title: '食品级安全',
      description: '严格按照食品安全标准生产，确保直接接触食物的安全性'
    },
    {
      icon: Leaf,
      title: '环保材质',
      description: '采用可降解环保纸张，响应绿色环保理念'
    },
    {
      icon: Zap,
      title: '防油防漏',
      description: '特殊涂层处理，有效防止油脂渗透，保持纸袋完整'
    },
    {
      icon: Heart,
      title: '精美设计',
      description: '专业设计团队，为您量身定制独特的包装外观'
    },
    {
      icon: Truck,
      title: '快速交付',
      description: '高效生产流程，确保订单按时交付到您手中'
    },
    {
      icon: Phone,
      title: '贴心服务',
      description: '专业客服团队，为您提供全程贴心的咨询服务'
    }
  ];

  return (
    <section id="features" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            为什么选择我们的纸袋？
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            我们专注于为餐饮行业提供高质量的包装解决方案，每一个细节都体现我们的专业与用心
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group bg-gradient-to-br from-amber-50 to-orange-50 p-8 rounded-2xl hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
            >
              <div className="flex items-center justify-center w-16 h-16 bg-amber-600 rounded-2xl mb-6 group-hover:scale-110 transition-transform">
                <feature.icon className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;